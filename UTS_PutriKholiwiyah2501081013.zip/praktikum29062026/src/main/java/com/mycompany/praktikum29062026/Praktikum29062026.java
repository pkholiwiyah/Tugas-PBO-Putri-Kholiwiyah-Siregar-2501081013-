/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikum29062026;

/**
 *
 * @author win10
 */
public class Praktikum29062026 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
